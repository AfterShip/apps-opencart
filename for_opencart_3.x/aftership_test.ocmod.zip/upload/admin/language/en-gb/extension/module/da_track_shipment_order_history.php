<?php

//Entry
$_['entry_courier'] = 'Courier:';
$_['entry_tracking_number'] = 'Tracking Number(s):';

$_['column_tracking_number'] = 'Tracking Number';
$_['column_tracking_number_remark'] = 'Comma separated for multiple tracking numbers e.g. RA123456789US, RA123456780US';
$_['column_courier'] = 'Courier';

$_['text_tracking_link'] = 'Tracking link(s):';
$_['text_track_url'] = 'Track URL:';

?>